dbPassword = 'mongodb+srv://lyhungphat:' + encodeURIComponent('01227920414') + '@cluster0.i9yy8.mongodb.net/Cluster0?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};